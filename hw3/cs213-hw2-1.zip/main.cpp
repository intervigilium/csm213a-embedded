#include "mbed.h"

Serial pc(USBTX, USBRX);
InterruptIn intr_pin(p30);
DigitalOut status_led(LED1);
Timer discharge_timer;
int last_timestamp_us;

double calc_capacitance_pf(int time_us);
void on_discharge_done();

double calc_capacitance_pf(int time_us) {
  double time_s = (double) time_us / 1000000;
  double v0 = 3.3;  // io pins put out 3.3v
  double r = 470 * 1000;  // resistor is 470kOhm
  double vt = 1.0;  // interrupt triggers 0 if voltage < 0.8v, 0.99 if 0.3
  double ln_vt_v0 = log(vt / v0);  // math.h is included by mbed.h
  return (-1 * time_s) / (r * ln_vt_v0) * 1000000000000;
}

void on_discharge_done() {
  int elapsed_us = discharge_timer.read_us() - last_timestamp_us;
  pc.printf("Time taken: %dus ##### ", elapsed_us);
  pc.printf("Capacitor: %fpF #####\n", calc_capacitance_pf(elapsed_us));
}

int main() {
  status_led = 1;
  intr_pin.fall(&on_discharge_done);
  discharge_timer.start();
  
  while (1) {
    pc.printf("\n ##### Beginning charge for 10ms ##### ");
    intr_pin.mode(PullUp);
    
    pc.printf("Charging for 10ms ##### ");
    wait_us(100);
    
    pc.printf("Starting discharge timer ##### ");
    intr_pin.mode(PullNone);
    last_timestamp_us = discharge_timer.read_us();
    
    status_led = !status_led;
    wait(1);
  }
}
