#include "mbed.h"
#include "match_checker/match_checker.h"
#include "touch_sensor/touch_sensor.h"

Serial pc(USBTX, USBRX);
MatchChecker::MatchChecker checker;

void OnSerialInput() {
  if (checker.AddTriggerChar(pc.getc())) {
    pc.printf("HOST ERROR\n\r");
  }
}

void OnSensorStateChange(PinName pin_name, int sensor_state) {
  if (sensor_state == SENSOR_PRESSED && pin_name == p29) {
    if (checker.AddInputChar('0')) {
      pc.printf("MATCH\n\r");
    }
  } else if (sensor_state == SENSOR_PRESSED && pin_name == p30) {
    if (checker.AddInputChar('1')) {
      pc.printf("MATCH\n\r");
    }
  }
}

int main() {
  checker = MatchChecker::MatchChecker();
  TouchSensor::TouchSensor t0 = TouchSensor::TouchSensor(p29);
  TouchSensor::TouchSensor t1 = TouchSensor::TouchSensor(p30);
  pc.attach(&OnSerialInput, Serial::RxIrq);
  t0.SetOnStateChangeCallback(&OnSensorStateChange);
  t1.SetOnStateChangeCallback(&OnSensorStateChange);

  while(1) {
    // background stuff, keep charging the capacitors
    t0.CycleCapacitor();
    t1.CycleCapacitor();
    wait_us(5000);
  }
}
