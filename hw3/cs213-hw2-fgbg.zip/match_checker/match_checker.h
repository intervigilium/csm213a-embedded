#ifndef MATCH_CHECKER_H_
#define MATCH_CHECKER_H_

#include "mbed.h"

namespace MatchChecker {

#define MAX_MATCH_LEN 15

class MatchChecker {
  public:
    MatchChecker();
    int AddTriggerChar(char c);
    bool AddInputChar(char c);
    ~MatchChecker();
  
  private:
    char *current_str_;
    char *trigger_str_;
    int trigger_str_len_;
    int trigger_str_idx_;
    int current_str_idx_;
};

} // namespace MatchChecker
#endif // MATCH_CHECKER_H_