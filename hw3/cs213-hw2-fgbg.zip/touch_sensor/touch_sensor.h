#ifndef TOUCH_SENSOR_H_
#define TOUCH_SENSOR_H_

#include "mbed.h"

namespace TouchSensor {

#define SENSOR_RELEASED 0
#define SENSOR_PRESSED 1

class TouchSensor {
  public:
    TouchSensor(PinName sensor_pin);
    
    void SetOnStateChangeCallback(void (*on_state_change)(PinName, int));
    void CycleCapacitor();
    ~TouchSensor();
  
  private:
    Timer *sensor_timer_;
    InterruptIn *sensor_pin_;
    PinName pin_name_;
    int last_state_;
    int last_timestamp_us_;
    double baseline_pf_;
    void (*on_state_change_)(PinName, int);
    void CalibrateSensor();
    void OnCapacitorDischarge();
    void OnCapacitorCalibrate();
};

} // namespace TouchSensor
#endif  // TOUCH_SENSOR_H_