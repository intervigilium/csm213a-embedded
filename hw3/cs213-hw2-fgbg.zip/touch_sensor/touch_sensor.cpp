#include "touch_sensor.h"

namespace {

double CalculateCapacitancePf(int time_us) {
  double time_s = (double) time_us / 1000000;
  double v0 = 3.3;  // io pins put out 3.3v
  double r = 470 * 1000;  // resistor is 470kOhm
  double vt = 1.0;  // interrupt triggers 0 if voltage < 0.8v, 0.99 if 0.3
  double ln_vt_v0 = log(vt / v0);  // math.h is included by mbed.h
  return (-1 * time_s) / (r * ln_vt_v0) * 1000000000000;
}

} // namespace

namespace TouchSensor {

TouchSensor::TouchSensor(PinName sensor_pin) {
  pin_name_ = sensor_pin;
  sensor_pin_ = new InterruptIn(sensor_pin);
  sensor_timer_ = new Timer();

  last_state_ = SENSOR_RELEASED;
  sensor_timer_->start();
  CalibrateSensor();
  sensor_pin_->fall(this, &TouchSensor::OnCapacitorDischarge);
}

void TouchSensor::SetOnStateChangeCallback(void (*on_state_change)(PinName, int)) {
  on_state_change_ = on_state_change;
}

void TouchSensor::CycleCapacitor() {
  sensor_pin_->mode(PullUp);
  wait_us(100);
  sensor_pin_->mode(PullNone);
  last_timestamp_us_ = sensor_timer_->read_us();
}

TouchSensor::~TouchSensor() {
  delete sensor_pin_;
  delete sensor_timer_;
}

void TouchSensor::CalibrateSensor() {
  int num_cycles = 5;
  baseline_pf_ = 0.0;

  sensor_pin_->fall(this, &TouchSensor::OnCapacitorCalibrate);
  for (int i = 0; i < num_cycles; i++) {
    CycleCapacitor();
    wait_us(100);
  }
  baseline_pf_ = baseline_pf_ / num_cycles;
}

void TouchSensor::OnCapacitorDischarge() {
  int elapsed_us = sensor_timer_->read_us() - last_timestamp_us_;
  double capacitance_pf = CalculateCapacitancePf(elapsed_us);
  if (capacitance_pf > baseline_pf_ * 1.25) {
    if (last_state_ == SENSOR_RELEASED) {
      last_state_ = SENSOR_PRESSED;
      (*on_state_change_)(pin_name_, SENSOR_PRESSED);
    }
  } else {
    if (last_state_ == SENSOR_PRESSED) {
      last_state_ = SENSOR_RELEASED;
      (*on_state_change_)(pin_name_, SENSOR_RELEASED);
    }
  }
}

void TouchSensor::OnCapacitorCalibrate() {
  int elapsed_us = sensor_timer_->read_us() - last_timestamp_us_;
  baseline_pf_ += CalculateCapacitancePf(elapsed_us);
}

} // namespace TouchSensor