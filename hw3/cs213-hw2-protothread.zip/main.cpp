#include "mbed.h"
#include "match_checker/match_checker.h"
#include "protothreads/pt.h"

#define SENSOR_RELEASED 0
#define SENSOR_PRESSED 1

struct CountdownTimer {
  int start_us;
  int total_us;
};

Serial pc(USBTX, USBRX);
Timer global_timer;
DigitalIn t0(p29);
DigitalIn t1(p30);
MatchChecker::MatchChecker checker;

static double t0_baseline = 0.0;
static double t1_baseline = 0.0;
static int t0_last_state = SENSOR_RELEASED;
static int t1_last_state = SENSOR_PRESSED;
static struct CountdownTimer t0_wait_timer;
static struct CountdownTimer t1_wait_timer;
static struct pt serial_pt;
static struct pt calibrate_t0_pt, check_t0_pt;
static struct pt calibrate_t1_pt, check_t1_pt;

double CalculateCapacitance(int time_us) {
  double time_s = (double) time_us / 1000000;
  double v0 = 3.3;  // io pins put out 3.3v
  double r = 470 * 1000;  // resistor is 470kOhm
  double vt = 1.0;  // interrupt triggers 0 if voltage < 0.8v, 0.99 if 0.3
  double ln_vt_v0 = log(vt / v0);  // math.h is included by mbed.h
  return (-1 * time_s) / (r * ln_vt_v0) * 1000000000000;
}

double CycleCapacitor(DigitalIn *sensor_pin) {
  int timestamp_us;

  sensor_pin->mode(PullUp);
  wait_us(100);
  sensor_pin->mode(PullNone);
  timestamp_us = global_timer.read_us();
  while (1) {
    if (sensor_pin->read() == 0) {
      int elapsed_us = global_timer.read_us() - timestamp_us;
      return CalculateCapacitance(elapsed_us);
    }
    wait_us(5);
  }
}

void SetTimer(struct CountdownTimer *timer, int time_us) {
  timer->start_us = global_timer.read_us();
  timer->total_us = time_us;
}

bool TimerExpired(struct CountdownTimer *timer) {
  return global_timer.read_us() - timer->start_us >= timer->total_us;
}

static 
PT_THREAD(check_serial_thread(struct pt *pt)) {
  PT_BEGIN(pt);
  
  while (1) {
    PT_WAIT_UNTIL(pt, pc.readable() > 0);
    if (checker.AddTriggerChar(pc.getc())) {
      pc.printf("HOST ERROR\n\r");
    }
  }
  
  PT_END(pt);
}

static 
PT_THREAD(calibrate_t0_thread(struct pt *pt)) {
  PT_BEGIN(pt);
  
  int num_cycles = 5;
  double total_capacitance = 0.0;

  for (int i = 0; i < num_cycles; i++) {
    total_capacitance += CycleCapacitor(&t0);
  }
  t0_baseline = total_capacitance / num_cycles;
  
  PT_END(pt);
}

static 
PT_THREAD(calibrate_t1_thread(struct pt *pt)) {
  PT_BEGIN(pt);
  
  int num_cycles = 5;
  double total_capacitance = 0.0;

  for (int i = 0; i < num_cycles; i++) {
    total_capacitance += CycleCapacitor(&t1);
  }
  t1_baseline = total_capacitance / num_cycles;
  
  PT_END(pt);
}

static 
PT_THREAD(check_t0_thread(struct pt *pt)) {
  PT_BEGIN(pt);

  while (1) {
    double t0_capacitance = CycleCapacitor(&t0);
    if (t0_capacitance > t0_baseline * 1.25) {  
      if (t0_last_state == SENSOR_RELEASED) {
        if (checker.AddInputChar('0')) {
          pc.printf("MATCH\n\r");
        }
      }
      t0_last_state = SENSOR_PRESSED;
    } else {
      t0_last_state = SENSOR_RELEASED;
    }
    SetTimer(&t0_wait_timer, 5000);
    PT_WAIT_UNTIL(pt, TimerExpired(&t0_wait_timer));
  }
  
  PT_END(pt);
}

static 
PT_THREAD(check_t1_thread(struct pt *pt)) {
  PT_BEGIN(pt);

  while (1) {
    double t1_capacitance = CycleCapacitor(&t1);
    if (t1_capacitance > t1_baseline * 1.25) {      
      if (t1_last_state == SENSOR_RELEASED) {
        if (checker.AddInputChar('1')) {
          pc.printf("MATCH\n\r");
        }
      }
      t1_last_state = SENSOR_PRESSED;
    } else {
      t1_last_state = SENSOR_RELEASED;
    }
    SetTimer(&t1_wait_timer, 5000);
    PT_WAIT_UNTIL(pt, TimerExpired(&t1_wait_timer));
  }
  
  PT_END(pt);
}

int main() {
  global_timer.start();
  checker = MatchChecker::MatchChecker();
  PT_INIT(&serial_pt);
  PT_INIT(&calibrate_t0_pt);
  PT_INIT(&check_t0_pt);
  PT_INIT(&calibrate_t1_pt);
  PT_INIT(&check_t1_pt);

  PT_SCHEDULE(calibrate_t0_thread(&calibrate_t0_pt));
  PT_SCHEDULE(calibrate_t1_thread(&calibrate_t1_pt));
  while (1) {
    PT_SCHEDULE(check_serial_thread(&serial_pt));
    PT_SCHEDULE(check_t0_thread(&check_t0_pt));
    PT_SCHEDULE(check_t1_thread(&check_t1_pt));
  }
}
