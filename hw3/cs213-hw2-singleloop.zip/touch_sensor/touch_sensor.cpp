#include "touch_sensor.h"

namespace {

double CalculateCapacitancePf(int time_us) {
  double time_s = (double) time_us / 1000000;
  double v0 = 3.3;  // io pins put out 3.3v
  double r = 470 * 1000;  // resistor is 470kOhm
  double vt = 1.0;  // interrupt triggers 0 if voltage < 0.8v, 0.99 if 0.3
  double ln_vt_v0 = log(vt / v0);  // math.h is included by mbed.h
  return (-1 * time_s) / (r * ln_vt_v0) * 1000000000000;
}

} // namespace

namespace TouchSensor {

TouchSensor::TouchSensor(PinName sensor_pin) {
  sensor_pin_ = new DigitalIn(sensor_pin);
  sensor_timer_ = new Timer();

  baseline_pf_ = 0.0;
  sensor_timer_->start();
}

void TouchSensor::CalibrateSensor() {
  int num_cycles = 5;
  double total_capacitance_pf = 0;
  
  for (int i = 0; i < num_cycles; i++) {
    total_capacitance_pf += CycleCapacitor();
  }
  baseline_pf_ = total_capacitance_pf / num_cycles;
}

int TouchSensor::ReadSensor() {
  double capacitance_pf = CycleCapacitor();
  if (capacitance_pf > baseline_pf_ * 1.25) {
    return SENSOR_PRESSED;
  } else {
    return SENSOR_RELEASED;
  }
}

TouchSensor::~TouchSensor() {
  delete sensor_pin_;
  delete sensor_timer_;
}

double TouchSensor::CycleCapacitor() {
  int timestamp_us;
  
  sensor_pin_->mode(PullUp);
  wait_us(100);
  sensor_pin_->mode(PullNone);
  timestamp_us = sensor_timer_->read_us();
  while (1) {
    if (sensor_pin_->read() == 0) {
      int elapsed_us = sensor_timer_->read_us() - timestamp_us;
      return CalculateCapacitancePf(elapsed_us);
    }
    wait_us(5);
  }
}

} // namespace TouchSensor