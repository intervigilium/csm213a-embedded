#ifndef TOUCH_SENSOR_H_
#define TOUCH_SENSOR_H_

#include "mbed.h"

namespace TouchSensor {

#define SENSOR_RELEASED 0
#define SENSOR_PRESSED 1

class TouchSensor {
  public:
    TouchSensor(PinName sensor_pin);
    void CalibrateSensor();
    int ReadSensor();
    ~TouchSensor();
  
  private:
    Timer *sensor_timer_;
    DigitalIn *sensor_pin_;
    int last_timestamp_us_;
    int is_touched_;
    double baseline_pf_;
    double CycleCapacitor();
};

} // namespace TouchSensor
#endif  // TOUCH_SENSOR_H_