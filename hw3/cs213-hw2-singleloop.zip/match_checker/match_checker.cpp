#include "match_checker.h"

namespace MatchChecker {

MatchChecker::MatchChecker() {
  trigger_str_idx_ = 0;
  current_str_idx_ = 0;
  trigger_str_len_ = MAX_MATCH_LEN;
  trigger_str_ = new char[trigger_str_len_ + 1];
  current_str_ = new char[trigger_str_len_ + 1];
}

int MatchChecker::AddTriggerChar(char c) {
  switch (c) {
    case 'S':
      trigger_str_idx_ = 0;
      trigger_str_len_ = MAX_MATCH_LEN;
      break;
    case 'E':
      trigger_str_len_ = trigger_str_idx_;
      trigger_str_[trigger_str_len_] = '\0';
      // clear current input str buffer
      delete current_str_;
      current_str_ = new char[trigger_str_len_ + 1];
      current_str_[trigger_str_len_] = '\0';
      current_str_idx_ = 0;
      break;
    case '0':
    case '1':
      if (trigger_str_idx_ < trigger_str_len_) {
        trigger_str_[trigger_str_idx_++] = c;
      } else {
        return -1;
      }
      break;
    case ' ':
      // do nothing on whitespace
      break;
    default:
      // bad input
      return -1;
  }
  return 0;
}

bool MatchChecker::AddInputChar(char c) {
  if (trigger_str_len_ == 0) {
    // refuse to match against null string
    return false;
  }
  if (trigger_str_idx_ != trigger_str_len_) {
    // refuse to match while inputting new trigger
    return false;
  }
  if (current_str_idx_ < trigger_str_len_) {
    current_str_[current_str_idx_++] = c;
  } else {
    // slide every input char down one index to make room
    for (int i = 0; i < trigger_str_len_ - 1; i++) {
      current_str_[i] = current_str_[i + 1];
    }
    current_str_[trigger_str_len_ - 1] = c;
  }
  if (current_str_idx_ == trigger_str_len_) {
    return strncmp(current_str_, trigger_str_, trigger_str_len_) == 0;
  } else {
    return false;
  }
}

MatchChecker::~MatchChecker() {
  delete trigger_str_;
  delete current_str_;
}

} // namespace MatchChecker