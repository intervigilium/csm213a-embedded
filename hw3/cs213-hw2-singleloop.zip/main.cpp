#include "mbed.h"
#include "match_checker/match_checker.h"
#include "touch_sensor/touch_sensor.h"

Serial pc(USBTX, USBRX);

int main() {
  int t0_last_state = SENSOR_RELEASED;
  int t1_last_state = SENSOR_RELEASED;
  MatchChecker::MatchChecker checker = MatchChecker::MatchChecker();
  TouchSensor::TouchSensor t0 = TouchSensor::TouchSensor(p29);
  TouchSensor::TouchSensor t1 = TouchSensor::TouchSensor(p30);
  t0.CalibrateSensor();
  t1.CalibrateSensor();

  while(1) {
    if (pc.readable()) {
      if (checker.AddTriggerChar(pc.getc())) {
        pc.printf("HOST ERROR\n\r");
      }
    } else {
      int t0_status = t0.ReadSensor();
      int t1_status = t1.ReadSensor();
      if (t0_status == SENSOR_PRESSED && t1_status == SENSOR_PRESSED) {
        pc.printf("TOUCH ERROR\n\r");
      }
      else if (t0_status == SENSOR_PRESSED && 
               t0_last_state != SENSOR_PRESSED) {
        if (checker.AddInputChar('0')) {
          pc.printf("MATCH\n\r");
        }
      } else if (t1_status == SENSOR_PRESSED && 
                 t1_last_state != SENSOR_PRESSED) {
        if (checker.AddInputChar('1')) {
          pc.printf("MATCH\n\r");
        }
      }
      t0_last_state = t0_status;
      t1_last_state = t1_status;
    }
    wait_us(5000);
  }
}
